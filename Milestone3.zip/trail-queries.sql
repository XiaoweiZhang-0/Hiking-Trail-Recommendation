USE Trail;

-- 1. List all trails that allow bicycles.
select trailID
from HikingTrails
where canBicycle = true;

-- 2. List the top 10 hiking trails with the most visited history. 
select trailID, count(*) AS vistedCOUNT
from HikingHistories
group by trailID
order by count(*) desc
limit 10;

-- 3. List the top 5 reviews with the most "likes"
select reviewID, count(*) as likeCount
from LikeReviews
group by reviewID
order by count(*) desc
limit 5;

-- 4. List the 5 most recommended hiking trails. 
select trailID, count(*) as recommendCount
from Recommendations
group by trailID
order by count(*) desc
limit 5;

-- 5. List the 10 longest hiking trails. 
select trailID, length
from HikingTrails
order by length desc
limit 10;

-- 6. What is the percentage of professional-level female users out of all female users?
SELECT 
((SELECT COUNT(*) FROM Users WHERE gender = "Female" AND hikingLevel = "Professional") / 
(SELECT COUNT(*) FROM Users WHERE gender = "Female")) AS ratio;

-- 7. Assume that userID 1 visited trailID 1, list all users that are not Friendships with this userID 1, but also have visited trrailID 1.
SELECT userID
FROM 
(SELECT userID, COALESCE(userId1, 0) AS userId1, COALESCE(userId2, 0) AS userId2
FROM Users LEFT JOIN Friendship 
ON Users.userID = Friendship.userId2
WHERE COALESCE(userId1, 0) != 1 AND userID != 1) AS NotFriendshipsWithUser1
INNER JOIN 
HikingHistories USING(userID) 
WHERE trailID = 1;

-- 8. Reorder the reviews of a certain trail by its "like" count.
SELECT	Reviews.*, COUNT(*) AS likesCount
FROM Reviews INNER JOIN LikeReviews USING(reviewID)
GROUP BY reviewID
ORDER BY COUNT(*) DESC;

-- 9. For user whose userID = 1, list the top 10  users having visited same trails, ordering by the count of same trails in descending order.
SELECT HikingHistories.userID, COUNT(*) AS sameTrailsCount
FROM HikingHistories INNER JOIN 
	(SELECT trailID 
	FROM HikingHistories
	WHERE userID = 1) AS userTrails
ON HikingHistories.trailID = userTrails.trailID AND UserID != 1
GROUP BY HikingHistories.userID
ORDER BY COUNT(*) DESC;

-- 10.What is the most frequent hiking level for all the users having visited trail with trailID = 1?
SELECT Users.hikingLevel, COUNT(*) as count
FROM HikingHistories INNER JOIN Users USING(userID)
WHERE HikingHistories.trailID = 1
GROUP BY Users.hikingLevel
ORDER BY COUNT(*) DESC
LIMIT 1;







